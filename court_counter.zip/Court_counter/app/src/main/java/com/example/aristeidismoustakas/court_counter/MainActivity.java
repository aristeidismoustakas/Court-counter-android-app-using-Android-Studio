package com.example.aristeidismoustakas.court_counter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static final String STATE_TEAMA = "firstTeamPoints";
    static final String STATE_TEAMB = "secondTeamPoints";
    static final String STATE_NAMEA = "nameA";
    static final String STATE_NAMEB = "nameB";
    int firstTeamPoints=0;
    int secondTeamPoints=0;
    String nameA="";
    String nameB="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, R.string.str_letsPlay , Toast.LENGTH_SHORT).show();
    }



    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the app state
        savedInstanceState.putInt(STATE_TEAMA, firstTeamPoints);
        savedInstanceState.putInt(STATE_TEAMB, secondTeamPoints);
        savedInstanceState.putString(STATE_NAMEA, nameA);
        savedInstanceState.putString(STATE_NAMEB, nameB);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }


    public void onRestoreInstanceState(Bundle savedInstanceState) {
        // Always call the superclass so it can restore the view hierarchy
        super.onRestoreInstanceState(savedInstanceState);

        // Restore state members from saved instance
        firstTeamPoints= savedInstanceState.getInt(STATE_TEAMA);
        secondTeamPoints=savedInstanceState.getInt(STATE_TEAMB);
        nameA=savedInstanceState.getString(STATE_NAMEA);
        nameB=savedInstanceState.getString(STATE_NAMEB);
        update();
    }



    public void threePoints(View v)
    {
        switch(v.getId())
        {
            case R.id.a3:
                firstTeamPoints+=3;
                update();
                break;

            case R.id.b3:
                secondTeamPoints+=3;
                update();
                break;
        }

    }

    public  void twoPoints(View v)
    {
        switch(v.getId())
        {
            case R.id.a2:
                firstTeamPoints+=2;
                update();
                break;

            case R.id.b2:
                secondTeamPoints+=2;
                update();
                break;
        }

    }

    public void freeThrow(View v)
    {

        switch(v.getId())
        {
            case R.id.a1:
                firstTeamPoints+=1;
                update();
                break;

            case R.id.b1:
                secondTeamPoints+=1;
                update();
                break;
        }

    }

    public void reset(View v)
    {
        firstTeamPoints=0;
        secondTeamPoints=0;
        update();
    }

    public void saveNames(View v)
    {
        switch (v.getId()){
            case R.id.teamA:
                EditText tvA=(EditText) findViewById(R.id.teamA);
                nameA=tvA.getText().toString();
                break;
            case R.id.teamB:
                EditText tvB=(EditText) findViewById(R.id.teamB);
                nameB=tvB.getText().toString();
                break;
        }
    }

    public void update(){
        TextView tvA=(TextView)findViewById(R.id.pointsA);
        tvA.setText(String.valueOf(firstTeamPoints));
        TextView tvB=(TextView) findViewById(R.id.pointsB);
        tvB.setText(String.valueOf(secondTeamPoints));

    }

}
